const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const userRoutes = require("./userRoutes");
const app = express();


app.listen(process.env.PORT || 3000, console.log('listening at 3000'));
app.use(express.static('public'));


/*
mongoose
    .connect(
        'mongodb+srv://siii.asrvg.mongodb.net/?retryWrites=true&w=majority',
        {
            dbName: 'siii',
            user: 'Yers',
            pass: 'Abuov1616',
            useNewUrlParser: true,
            useUnifiedTopology: true
        }
    )
    .then(() => {
        console.log('Mongodb connected');
        });
*/

mongoose
    .connect("mongodb://localhost:27017/demo", { useNewUrlParser: true })
    .then((_) => console.log("Connected to DB"))
    .catch((err) => console.error("error", err));

app.use(express.json());
app.use("/auth", userRoutes);
